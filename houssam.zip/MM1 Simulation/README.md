L'espace d'état est l'ensemble {0,1,2,3,...}, où la valeur correspond au nombre de clients dans le système. Nous notons Pn la probabilité de n clients dans le système.

Les arrivées se produisent au rythme λ selon un processus de Poisson, qui fait passer le système de l'état i à l'état i+1 (puisqu'un client est arrivé). Les temps de service sont distribués de manière exponentielle avec le paramètre de débit μ de sorte que 1/μ est le temps de service moyen.

Un serveur unique sert les clients un à la fois depuis le début de la file d'attente, selon une discipline du premier arrivé, premier servi. Lorsque le service est terminé, le client quitte la file d'attente et le nombre de clients dans le système diminue de un, c'est-à-dire que le système passe de l'état i à i-1.
